package Basic_Program;

import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Smoke_Testing {

	public static void main(String[] args) throws Exception
	{

		Scanner s=new Scanner(System.in);
		System.out.println("Enter Email: ");
		String Email=s.next();
		System.out.println("Enter Password");
		String pwd=s.next();

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\HP\\Desktop\\EDU-Data\\Automation Testing\\BrowserExtension\\chromedriver.exe");

		WebDriver driver=new ChromeDriver(); 

		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();

		Thread.sleep(2000);
		driver.get("https://luma.enablementadobe.com/content/luma/us/en.html");

		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"top\"]/div[1]/div/ul[2]/li[2]/a")).click();

		Thread.sleep(2000);

		driver.findElement(By.xpath("//input[@placeholder='Email']")).sendKeys(Email);

		Thread.sleep(2000);

		driver.findElement(By.xpath("//input[@placeholder='Password']")).sendKeys(pwd);

		Thread.sleep(2000);

		driver.findElement(By.xpath("//button[@type='submit']")).submit();

		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"top\"]/div[1]/div/ul[2]/li[1]/a")).click();

		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"text-6d805ea60a\"]/p/a")).click();

		Thread.sleep(3000);

		driver.findElement(By.xpath("//*[@id=\"top\"]/div[1]/div/ul[2]/li[2]/a")).click();

		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"tabs-1\"]/header/button[1]")).click();

		Thread.sleep(2000);

		WebElement l = driver.findElement(By.xpath("//*[@id=\"profile-edit-form\"]/div/div/div[4]/div[2]/input"));
		l.clear();
		Thread.sleep(1000);
		l.sendKeys("USA");
		
		Thread.sleep(1000);
		
		driver.findElement(By.xpath("//*[@id=\"tabs-1\"]/header/button[2]")).click();
		
		Thread.sleep(1000);
		

		driver.findElement(By.xpath("/html/body/div[3]/div[3]/div/div/div[1]/div/div/div/div/div/div/div[2]/button")).click();
		
		Thread.sleep(1000);
		

		driver.findElement(By.xpath("/html/body/div[9]/div[2]/div/div/form/div[1]/div[2]/input")).sendKeys("Luma888");
		
		Thread.sleep(1000);
		driver.findElement(By.xpath("/html/body/div[9]/div[2]/div/div/form/div[1]/div[4]/input")).sendKeys("Luma222");
		
		Thread.sleep(1000);
		driver.findElement(By.xpath("/html/body/div[9]/div[2]/div/div/form/div[1]/div[6]/input")).sendKeys("Luma222");
		
		//Test for Cancel in changing password
		//Thread.sleep(1000);
		//driver.findElement(By.xpath("/html/body/div[9]/div[2]/div/div/form/div[2]/div/button[1]")).click();
		
		Thread.sleep(1000);

		driver.findElement(By.xpath("//*[@id=\"change-password-submit\"]")).submit();
		
		Thread.sleep(2000);

		driver.navigate().back();
		
		Thread.sleep(1000);

		driver.findElement(By.xpath("/html/body/div[9]/div[1]")).click();
		
		Thread.sleep(3000);

		driver.findElement(By.xpath("//*[@id=\"top\"]/div[1]/div/ul[2]/li[3]/div/a")).click();
		
		Thread.sleep(2000);

		driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/a")).click();
		
		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"top\"]/div[1]/div/ul[2]/li[6]/div/a")).click();
		
		Thread.sleep(2000);

		driver.findElement(By.xpath("/html/body/div[5]/div[1]/div[1]/a/i")).click();
		
		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"top\"]/div[1]/div/ul[2]/li[7]/a")).click();
		
		Thread.sleep(2000);
		s.close();	
		Thread.sleep(2000);
		driver.close();		
		//Password=Luma222


	}

}
