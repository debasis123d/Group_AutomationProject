package Main_Functionlaties;

import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AboutUs {

	public static void main(String[] args) throws Exception
	{


		Scanner s=new Scanner(System.in);
		System.out.println("Enter Email: ");
		String Email=s.next();
		System.out.println("Enter Password");
		String pwd=s.next();

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\HP\\Desktop\\EDU-Data\\Automation Testing\\BrowserExtension\\chromedriver.exe");

		WebDriver driver=new ChromeDriver(); 

		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();

		Thread.sleep(2000);
		driver.get("https://luma.enablementadobe.com/content/luma/us/en.html");

		Thread.sleep(2000);

		JavascriptExecutor js=(JavascriptExecutor)driver;

		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"top\"]/div[1]/div/ul[2]/li[2]/a")).click();

		Thread.sleep(2000);

		driver.findElement(By.xpath("//input[@placeholder='Email']")).sendKeys(Email);

		Thread.sleep(2000);

		driver.findElement(By.xpath("//input[@placeholder='Password']")).sendKeys(pwd);

		Thread.sleep(2000);

		driver.findElement(By.xpath("//button[@type='submit']")).submit();

		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"navigation-fd3cee8df8\"]/ul/li[5]/a")).click();

		Thread.sleep(2000);

		WebElement element=driver.findElement(By.xpath("//*[@id=\"text-e9da61d8ab\"]/h4/i"));

		js.executeScript("arguments[0].scrollIntoView()",element);

		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"page-31f5d67aad\"]/div[1]/div/div/div[3]/div/div[2]/ul/li[1]/article/a/span[1]")).click();

		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"form-text-1099988975\"]")).sendKeys("MNB");

		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"form-text-552840626\"]")).sendKeys("axyb@gmail.com");

		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"form-text-301134498\"]")).sendKeys("0123456789");

		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"form-text-1102270954\"]")).sendKeys("For Appreciation");


		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"form-button-26787124\"]")).submit();

		s.close();

	}

}
