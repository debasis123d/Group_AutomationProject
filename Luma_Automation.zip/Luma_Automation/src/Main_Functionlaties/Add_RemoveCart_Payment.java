package Main_Functionlaties;

import java.util.Scanner;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Add_RemoveCart_Payment {

	public static void main(String[] args) throws Exception
	{

		Scanner s=new Scanner(System.in);
		System.out.println("Enter Email: ");
		String Email=s.next();
		System.out.println("Enter Password");
		String pwd=s.next();

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\HP\\Desktop\\EDU-Data\\Automation Testing\\BrowserExtension\\chromedriver.exe");

		WebDriver driver=new ChromeDriver(); 

		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();

		Thread.sleep(2000);
		driver.get("https://luma.enablementadobe.com/content/luma/us/en.html");

		Thread.sleep(2000);
		JavascriptExecutor js=(JavascriptExecutor)driver;

		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"top\"]/div[1]/div/ul[2]/li[2]/a")).click();

		Thread.sleep(2000);

		driver.findElement(By.xpath("//input[@placeholder='Email']")).sendKeys(Email);

		Thread.sleep(2000);

		driver.findElement(By.xpath("//input[@placeholder='Password']")).sendKeys(pwd);

		Thread.sleep(2000);

		driver.findElement(By.xpath("//button[@type='submit']")).submit();

		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"navigation-fd3cee8df8\"]/ul/li[2]/a")).click();

		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"klaro\"]/div/div/div/div/div/button[2]")).click();

		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"page-e590d8a77d\"]/div[1]/div/div/div[2]/div/div/div/p[2]/a")).click();

		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"page-7cfb237d1e\"]/div[1]/div/div/div[5]/div/div[1]/div/a")).click();

		Thread.sleep(2000);

		WebElement element=driver.findElement(By.xpath("//*[@id=\"page-d514571e48\"]/div[1]/div/div/div[4]/div/div[1]/div/div[3]/div/div/div[1]"));

		js.executeScript("arguments[0].scrollIntoView()",element);

		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"page-d514571e48\"]/div[1]/div/div/div[4]/div/div[2]/div/ul/li[13]/div/a")).click();

		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"page-063646cae7\"]/div[1]/div/div/div[3]/div/div/div[2]/form/div[4]/div[4]/label/div")).click();

		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"page-063646cae7\"]/div[1]/div/div/div[3]/div/div/div[2]/form/div[5]/div/div[2]/div/button")).submit();

		Thread.sleep(2000);

		driver.navigate().back();

		Thread.sleep(2000);

		driver.navigate().back();

		Thread.sleep(2000);

		driver.navigate().back();

		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"page-d514571e48\"]/div[1]/div/div/div[4]/div/div[2]/div/ul/li[15]/div/a")).click();

		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"page-d8a20d2bc0\"]/div[1]/div/div/div[3]/div/div/div[2]/form/div[4]/div[4]/label/div")).click();

		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"page-d8a20d2bc0\"]/div[1]/div/div/div[3]/div/div/div[2]/form/div[5]/div/div[2]/div/button")).submit();

		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"top\"]/div[1]/div/ul[2]/li[6]/div/a")).click();

		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"page-d8a20d2bc0\"]/div[3]/div[2]/div[1]/div[1]/div[2]/form/button/i")).click();

		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"page-d8a20d2bc0\"]/div[3]/div[2]/div[2]/a")).click();

		Thread.sleep(1500);

		driver.findElement(By.xpath("//*[@id=\"page-d534efa0bb\"]/div[1]/div/div/div[2]/div/div[5]/a")).click();

		Thread.sleep(3000);

		driver.findElement(By.xpath("//input[@placeholder='Firstname']")).sendKeys("fcd");

		Thread.sleep(2000);

		driver.findElement(By.xpath("//input[@placeholder='Lastname']")).sendKeys("jkl");
		Thread.sleep(2000);

		driver.findElement(By.xpath("//input[@placeholder='Address line 1']")).sendKeys("Manhattan");
		Thread.sleep(2000);

		driver.findElement(By.xpath("//input[@placeholder='Address line 2']")).sendKeys("New York");
		Thread.sleep(2000);

		driver.findElement(By.xpath("//input[@placeholder='City']")).sendKeys("New York");


		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"checkout\"]/div[2]/div/div[2]/div[3]/label")).click();

		Thread.sleep(2000);

		driver.findElement(By.xpath("//input[@placeholder='Card Number']")).sendKeys("545376548765");

		Thread.sleep(2000);

		driver.findElement(By.xpath("//input[@placeholder='Expiration date']")).sendKeys("2050");

		Thread.sleep(2000);


		driver.findElement(By.xpath("//input[@placeholder='Security Code']")).sendKeys("098");

		Thread.sleep(2000);
		driver.findElement(By.id ("form-button-1573303396")).submit();

		Thread.sleep(2000);
		driver.findElement(By.id ("form-button-1244170883")).submit();

		Thread.sleep(6000);

		driver.findElement(By.xpath("//*[@id=\"page-a14eeab375\"]/div[1]/div/div/div[2]/div/div[5]/a")).click();

		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"top\"]/div[1]/div/ul[2]/li[7]/a")).click();

		driver.close();
		s.close();
	}

}
