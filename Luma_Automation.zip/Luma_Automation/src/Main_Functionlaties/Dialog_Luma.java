package Main_Functionlaties;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Dialog_Luma {

	public static void main(String[] args) throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\HP\\Desktop\\EDU-Data\\Automation Testing\\BrowserExtension\\chromedriver.exe");

		WebDriver driver=new ChromeDriver(); 

		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();

		driver.get("https://luma.enablementadobe.com/content/luma/us/en.html");

		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"top\"]/div[1]/div/ul[2]/li[2]/a")).click();

		Thread.sleep(2000);

		String Email=JOptionPane.showInputDialog("Enter Email");
		driver.findElement(By.xpath("//input[@placeholder='Email']")).sendKeys(Email);

		Thread.sleep(2000);
		String pwd=JOptionPane.showInputDialog("Enter Password");
		driver.findElement(By.xpath("//input[@placeholder='Password']")).sendKeys(pwd);

		Thread.sleep(2000);

		driver.findElement(By.xpath("//button[@type='submit']")).submit();

		Thread.sleep(3000);

		driver.findElement(By.xpath("//*[@id=\"top\"]/div[1]/div/ul[2]/li[7]/a")).click();

		Thread.sleep(2000);


		driver.close();

	}

}
