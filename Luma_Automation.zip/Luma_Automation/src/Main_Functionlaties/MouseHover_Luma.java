package Main_Functionlaties;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;


public class MouseHover_Luma {

	public static void main(String[] args) throws Exception
	{

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\HP\\Desktop\\EDU-Data\\Automation Testing\\BrowserExtension\\chromedriver.exe");

		WebDriver driver=new ChromeDriver(); 

		Luma l=new Luma();

		l.maximizeBroswer(driver);
		l.url(driver);

		Thread.sleep(2000);
		l.enterEmail(driver, "axyb@gmail.com");
		l.enterPassword(driver, "Luma222");

		Thread.sleep(2000);
		l.clickOnLoginButton(driver);


		Thread.sleep(3000);
		Actions a=new Actions(driver);

		List<WebElement>ls=driver.findElements(By.xpath("//*[@id=\"navigation-fd3cee8df8\"]/ul/li[1]/ul"));


		int size=ls.size();
		System.out.println("No of Webelements: " +size);


		for (int i=1; i<=size; i++)
		{

			Thread.sleep(3000);

			System.out.println(driver.findElement(By.xpath("//ul[@class='cmp-navigation__group']["+i+"]")).getText());


			a.moveToElement(driver.findElement(By.xpath("//*[@id=\"navigation-fd3cee8df8\"]/ul/li[1]"))).perform();


			a.moveToElement(driver.findElement(By.xpath("//*[@id=\"navigation-fd3cee8df8\"]/ul/li[1]/ul/li[2]"))).click().perform();

		}

	}

}
