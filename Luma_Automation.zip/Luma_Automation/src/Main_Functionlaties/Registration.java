package Main_Functionlaties;

import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Registration {

	public static void main(String[] args) throws Exception
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter FirstName: ");
		String FirstName=s.next();
		System.out.println("Enter LastName: ");
		String LastName=s.next();
		System.out.println("Enter Email: ");
		String Email=s.next();
		System.out.println("Enter Password");
		String pwd=s.next();
		System.out.println("Confirm Password");
		String Confirmpwd=s.next();

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\HP\\Desktop\\EDU-Data\\Automation Testing\\BrowserExtension\\chromedriver.exe");

		WebDriver driver=new ChromeDriver(); 

		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();

		Thread.sleep(2000);
		driver.get("https://luma.enablementadobe.com/content/luma/us/en.html");

		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"top\"]/div[1]/div/ul[2]/li[2]/a")).click();

		Thread.sleep(1500);
		JavascriptExecutor js=(JavascriptExecutor)driver;

		Thread.sleep(1500);
		js.executeScript("window.scrollBy(0,500)");

		Thread.sleep(2000);

		driver.findElement(By.xpath("/html/body/div[3]/div[3]/div/div/div/div/div/div/div/div/form/div[2]/span[1]/a")).click();

		Thread.sleep(2000);

		driver.findElement(By.xpath("/html/body/div[3]/div[3]/div/div/div/div/div/div/div/div/form/div[1]/div/input")).sendKeys(FirstName);

		Thread.sleep(2000);

		driver.findElement(By.xpath("/html/body/div[3]/div[3]/div/div/div/div/div/div/div/div/form/div[2]/div/input")).sendKeys(LastName);

		Thread.sleep(2000);

		driver.findElement(By.xpath("/html/body/div[3]/div[3]/div/div/div/div/div/div/div/div/form/div[3]/div/input")).sendKeys(Email);

		Thread.sleep(2000);

		driver.findElement(By.xpath("/html/body/div[3]/div[3]/div/div/div/div/div/div/div/div/form/div[6]/div/input")).sendKeys(pwd);

		Thread.sleep(2000);

		driver.findElement(By.xpath("/html/body/div[3]/div[3]/div/div/div/div/div/div/div/div/form/div[7]/div/input")).sendKeys(Confirmpwd);

		Thread.sleep(2000);

		driver.findElement(By.xpath("//button[@evt='click=register']")).click();

		Thread.sleep(5000);

		driver.findElement(By.xpath("/html/body/div[3]/div[3]/div/div/div/div/div/div/div/div/div[2]/a")).click();
		
		Thread.sleep(2000);
		s.close();

	}

}
